document.getElementById("joinBtn").addEventListener("click", function () {
  alert("Tournament registration will be connected here.");
});
